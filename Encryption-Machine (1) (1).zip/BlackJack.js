
var deal = function() {
  card = Math.floor(Math.random()*52+1);
  return card;
};


var dealerhand = function(x, y) {
    cardDealer = Math.floor(Math.random()*(21 - 17 + 1)+17);
    return cardDealer;
}


var card1 = deal();
var card2 = deal();
var dealer = dealerhand();
var x = 17;
var y = 21;


var getValue = function(card) {

    if(card % 13 === 0 || card % 13 === 11 || card % 13 === 12){
        return 10;   
    }
    if(card % 13 === 1){
        return 11;   
    }
    else{
        return card % 13;
    }
}


   
function score() {

    if ((getValue(card1) + getValue(card2)) > 22){
        return "Busted!";
    }
    else if (getValue(cardDealer) > getValue(card1) + getValue(card2)){
        return "You lose!";
    }
    else if (getValue(cardDealer) === getValue(card1) + getValue(card2)){
        return "Draw!";
    }
    else{
        return getValue(card1) + getValue(card2);
    }
}

